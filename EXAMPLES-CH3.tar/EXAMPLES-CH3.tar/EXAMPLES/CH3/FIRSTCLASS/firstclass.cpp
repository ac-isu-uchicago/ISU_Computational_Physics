#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {

  std::string s1="Trout ";
  std::string s2="Fishing ";
  std::string s3="In ";
  std::string s4="America";
  std::cout << s1+s2+s3+s4 << std::endl;
  
  return 0;
}
