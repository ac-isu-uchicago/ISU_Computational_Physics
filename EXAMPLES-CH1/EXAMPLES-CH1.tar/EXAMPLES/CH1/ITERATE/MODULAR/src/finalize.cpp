#include "iterate.h"
// 
// finalize: 
// 
void finalize(Control *control) {   
   delete control; 
}
